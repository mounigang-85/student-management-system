﻿using Microsoft.EntityFrameworkCore;
using StudentManagement.Data.Contracts;
using StudentManagement.Data.Entities;
using StudentManagement.Data.Infrastructure;
using StudentManagement.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagement.Data.Repositories
{
    public class StudentRepository : IStudentRepository
    {
        public DatabaseContext DatabaseContext { get; set; }
        public StudentRepository(DatabaseContext databaseContext)
        {
            DatabaseContext = databaseContext;
        }
        public async Task<List<Student>> GetAllStudentsAsync()
        {
            var students = await DatabaseContext.Students.ToListAsync();
            return students;
        }

        public async Task<Student?> GetStudentByIdAsync(int id)
        {
            return await DatabaseContext.Students.FindAsync(id);
        }

        public async Task<Student?> GetStudentByEmailAsync(string email)
        {
            return await DatabaseContext.Students.FirstOrDefaultAsync(e => e.Email == email);
        }

        public async Task<Student> AddStudentAsync(AddStudent addStudent)
        {
            var student = new Student
            {
                Name = addStudent.Name,
                Email = addStudent.Email,
                Age = addStudent.Age,
                Course = addStudent.Course,
                CreatedDate = DateTime.UtcNow
            };

            DatabaseContext.Students.Add(student);
            await DatabaseContext.SaveChangesAsync();

            return student;
        }
        public async Task<Student> UpdateStudentAsync(Student student)
        {
            DatabaseContext.Students.Update(student);
            await DatabaseContext.SaveChangesAsync();
            return student;
        }

        public async Task<bool> DeleteStudentAsync(int id)
        {
            var student = await DatabaseContext.Students.FindAsync(id);
            if (student == null) return false;

            DatabaseContext.Students.Remove(student);
            await DatabaseContext.SaveChangesAsync();
            return true;
        }
    }
}
