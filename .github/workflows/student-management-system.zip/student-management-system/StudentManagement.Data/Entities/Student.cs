﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagement.Data.Entities
{
    public partial  class Student
    {
        public int Id { get; set; }

        public string Name { get; set; } = null!;

        public string Email { get; set; } = null!;

        public int Age { get; set; }

        public string Course { get; set; } = null!;

        public DateTime CreatedDate { get; set; }
    }
}
