﻿using StudentManagement.Data.Entities;
using StudentManagement.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagement.Data.Contracts
{
    public interface IStudentRepository
    {
        Task<List<Student>> GetAllStudentsAsync();

        Task<Student> GetStudentByEmailAsync(string email);
        Task<Student> GetStudentByIdAsync(int id);
        Task<Student> AddStudentAsync(AddStudent Addstudent);
        Task<Student> UpdateStudentAsync(Student student);
        Task<bool> DeleteStudentAsync(int id);
    }
}
