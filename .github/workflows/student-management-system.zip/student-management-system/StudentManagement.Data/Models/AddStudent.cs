﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagement.Data.Models
{
    public class AddStudent
    {
        public string Name { get; set; } = null!;

        public string Email { get; set; } = null!;

        public int Age { get; set; }

        public string Course { get; set; } = null!;
    }
}
