﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagement.Data.Models
{
    public class EditStudent
    {
        /// <summary>
        /// Student name
        /// </summary>
        /// <example>Mounika</example>
        public string Name { get; set; }

        /// <summary>
        /// Student age
        /// </summary>
        /// <example>25</example>
        public int Age { get; set; }

        /// <summary>
        /// Course name
        /// </summary>
        /// <example>DotNet</example>
        public string Course { get; set; }
    }
}
