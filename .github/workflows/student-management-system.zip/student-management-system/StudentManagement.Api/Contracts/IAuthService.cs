﻿namespace StudentManagement.Contracts
{
    public interface IAuthService
    {
        Task<string> CreateTokenAsync(string email);
    }
}
