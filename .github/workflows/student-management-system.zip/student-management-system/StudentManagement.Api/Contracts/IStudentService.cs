﻿using StudentManagement.Data.Entities;
using StudentManagement.Data.Models;

namespace StudentManagement.Contracts
{
    public interface IStudentService
    {
        Task<List<Student>> GetAllStudentsAsync();
        Task<Student> AddStudentAsync(AddStudent addStudent);
        Task<Student> UpdateStudentAsync(string email, EditStudent editstudent);
        Task<bool> DeleteStudentAsync(int id);

        Task<Student> GetStudentDetailsByEmail(string email);
    }
}
