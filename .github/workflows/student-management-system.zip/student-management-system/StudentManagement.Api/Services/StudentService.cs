﻿using AutoWrapper.Wrappers;
using StudentManagement.Contracts;
using StudentManagement.Data.Contracts;
using StudentManagement.Data.Entities;
using StudentManagement.Data.Models;

namespace StudentManagement.Services
{
    public class StudentService : IStudentService
    {
        private readonly IStudentRepository _repository;
        private readonly ILogger<StudentService> _logger;

        public StudentService(IStudentRepository repository, ILogger<StudentService> logger)
        {
            _repository = repository;
            _logger = logger;
        }

        public async Task<List<Student>> GetAllStudentsAsync()
        {
            _logger.LogInformation("Fetching all students");
            var students = await _repository.GetAllStudentsAsync();
            if (students == null || students.Count == 0)
            {
                throw new ApiProblemDetailsException("Students Not Found", StatusCodes.Status404NotFound);
            }
            return students;
        }

        public async Task<Student> GetStudentDetailsByEmail(string email)
        {
            var studentDetails = await _repository.GetStudentByEmailAsync(email);
            return studentDetails;
        }

        public async Task<Student> AddStudentAsync(AddStudent addstudent)
        {
            _logger.LogInformation("Adding new student: {Name}", addstudent.Name);
            var existingstudent = await _repository.GetStudentByEmailAsync(addstudent.Email);
            if (existingstudent != null)
            {
                throw new ApiProblemDetailsException("Student with the same email already exists", StatusCodes.Status400BadRequest);
            }
            return await _repository.AddStudentAsync(addstudent);
        }

        public async Task<Student> UpdateStudentAsync(string email, EditStudent editStudent)
        {
            _logger.LogInformation("Updating student with Email: {Email}", email);

            var existing = await _repository.GetStudentByEmailAsync(email);

            if (existing == null)
            {
                _logger.LogWarning("Student not found with Email: {Email}", email);
                return null;
            }

            // ✏️ Update only allowed fields
            existing.Name = editStudent.Name;
            existing.Age = editStudent.Age;
            existing.Course = editStudent.Course;

            return await _repository.UpdateStudentAsync(existing);
        }

        public async Task<bool> DeleteStudentAsync(int id)
        {
            _logger.LogInformation("Deleting student with Id: {Id}", id);

            var result = await _repository.DeleteStudentAsync(id);

            if (!result)
                _logger.LogWarning("Student not found for deletion: {Id}", id);

            return result;
        }
    }
}
