﻿using AutoWrapper.Wrappers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StudentManagement.Contracts;
using StudentManagement.Data.Entities;
using StudentManagement.Data.Models;
using StudentManagement.Services;
using Swashbuckle.AspNetCore.Annotations;
using System.Security.Claims;

namespace StudentManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentsController : ControllerBase
    {
        public readonly IStudentService _studentService;
        public StudentsController(IStudentService studentService)
        {
            _studentService = studentService;
        }
        [HttpGet]
        [Authorize]
        [SwaggerOperation(Summary = "Get all students", Description = "Returns list of all students")]
        [SwaggerResponse(200, "Students fetched successfully")]
        [SwaggerResponse(401, "Unauthorized")]
        public async Task<ApiResponse> GetStudents()
        {
            var loggedInUser = await GetLoggedInUserDetails();
            if (loggedInUser == null)
            {
                return new ApiResponse("Unauthorized to fetch student details", StatusCodes.Status401Unauthorized);
            }
            var students = await _studentService.GetAllStudentsAsync();
            return new ApiResponse(students, StatusCodes.Status200OK);
        }

        [HttpPost]
        [Authorize]
        [SwaggerOperation(Summary = "Add new student", Description = "Creates a new student record")]
        [SwaggerResponse(201, "Student created successfully")]
        [SwaggerResponse(400, "Invalid request")]
        public async Task<ApiResponse> Add(AddStudent addStudent)
        {
            var loggedInUser = await GetLoggedInUserDetails();
            if (loggedInUser == null)
            {
                return new ApiResponse("Unauthorized to add student", StatusCodes.Status401Unauthorized);
            }
            var result = await _studentService.AddStudentAsync(addStudent);
            return new ApiResponse("Student added successfully", StatusCodes.Status201Created);
        }

        [HttpPut]
        [Authorize]
        [SwaggerOperation(Summary = "Update student", Description = "Updates logged-in student details")]
        [SwaggerResponse(200, "Student updated successfully")]
        [SwaggerResponse(401, "Unauthorized")]
        public async Task<ApiResponse> Update(string email, EditStudent editstudent)
        {
            var loggedInUser = await GetLoggedInUserDetails();
            if (loggedInUser == null)
            {
                return new ApiResponse("Unauthorized to update student details", StatusCodes.Status401Unauthorized);
            }
            var result = await _studentService.UpdateStudentAsync(loggedInUser.Email, editstudent);
            return new ApiResponse("Student details updated successfully", StatusCodes.Status200OK);
        }

        [HttpDelete("{id}")]
        [Authorize]
        [SwaggerOperation(Summary = "Delete student", Description = "Deletes student by Id")]
        [SwaggerResponse(200, "Deleted successfully")]
        [SwaggerResponse(404, "Student not found")]
        public async Task<ApiResponse> Delete(int id)
        {
            var loggedInUser = await GetLoggedInUserDetails();
            if (loggedInUser == null)
            {
                return new ApiResponse("Unauthorized to delete the student", StatusCodes.Status401Unauthorized);
            }
            var result = await _studentService.DeleteStudentAsync(id);
            return new ApiResponse("Student Details deleted successfully", StatusCodes.Status200OK);
        }

        private async Task<Student> GetLoggedInUserDetails()
        {
            var claimsIdentity = (ClaimsIdentity)HttpContext.User.Identity;
            var email = claimsIdentity.FindFirst(ClaimTypes.Email)?.Value;
            var student = await _studentService.GetStudentDetailsByEmail(email);
            return student;
        }
    }
}
