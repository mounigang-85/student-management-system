﻿using AutoWrapper.Wrappers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StudentManagement.Contracts;
using Swashbuckle.AspNetCore.Annotations;

namespace StudentManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;

        public AuthController(IAuthService authService)
        {
            _authService = authService;
        }

        /// <summary>
        /// Authenticates user and generates JWT token
        /// </summary>
        /// <param name="email">User email address</param>
        /// <returns>JWT token</returns>
        [HttpPost("login")]
        [AllowAnonymous]
        [SwaggerOperation(
            Summary = "User Login",
            Description = "Generates JWT token based on provided email"
        )]
        [SwaggerResponse(StatusCodes.Status200OK, "Token generated successfully", typeof(ApiResponse))]
        [SwaggerResponse(StatusCodes.Status400BadRequest, "Invalid email")]
        public async Task<ApiResponse> Login([FromQuery] string email)
        {
            var token = await _authService.CreateTokenAsync(email);

            return new ApiResponse(token, StatusCodes.Status200OK);
        }
    }
}
